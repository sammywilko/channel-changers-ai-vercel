/**
 * Channel Changers - Prompt Usage Examples
 * 
 * Shows how to integrate prompts with Gemini API in your app.
 * Drop this into services/aiService.ts
 */

import { GoogleGenerativeAI } from '@google/generative-ai';
import PROMPTS, { 
  buildBrandResearchPrompt,
  buildScriptGenerationPrompt, 
  buildBangerCheckPrompt,
  ScriptInput,
  BangerCheckInput 
} from './prompts';

// Initialize Gemini
const genAI = new GoogleGenerativeAI(process.env.GOOGLE_AI_API_KEY!);

// Model selection based on task complexity
const models = {
  fast: genAI.getGenerativeModel({ model: 'gemini-2.0-flash-exp' }),
  thinking: genAI.getGenerativeModel({ model: 'gemini-2.0-flash-thinking-exp' }),
  pro: genAI.getGenerativeModel({ model: 'gemini-1.5-pro' }),
};

// ===========================================
// STEP 0: Brand Research
// ===========================================
export async function runBrandResearch(
  brandUrl: string,
  competitorUrls: string[],
  additionalContext?: string
) {
  const prompt = buildBrandResearchPrompt(brandUrl, competitorUrls, additionalContext);
  
  // Use thinking model for complex research
  const result = await models.thinking.generateContent({
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    generationConfig: {
      maxOutputTokens: 8000,
      temperature: 0.7,
    },
  });
  
  const text = result.response.text();
  
  // Extract JSON from response
  const jsonMatch = text.match(/```json\n([\s\S]*?)\n```/);
  if (jsonMatch) {
    return JSON.parse(jsonMatch[1]);
  }
  
  throw new Error('Failed to parse brand research output');
}

// ===========================================
// STEP 1: Daily Competitor Monitor
// ===========================================
export async function runCompetitorMonitor(
  brandContext: any,
  competitorContent: any[]
) {
  const prompt = `
${PROMPTS.DAILY_COMPETITOR_MONITOR}

---

## YOUR TASK

Analyze the following competitor content and generate today's report.

BRAND CONTEXT:
${JSON.stringify(brandContext, null, 2)}

COMPETITOR CONTENT (Last 48 hours):
${competitorContent.map(c => `
Source: ${c.handle}
URL: ${c.url}
Hook: "${c.hook}"
Engagement: ${c.engagement}
`).join('\n---\n')}

Generate the complete intelligence report.
`;

  const result = await models.fast.generateContent(prompt);
  return JSON.parse(result.response.text().match(/```json\n([\s\S]*?)\n```/)?.[1] || '{}');
}

// ===========================================
// STEP 2: Script Generation
// ===========================================
export async function generateScript(input: ScriptInput) {
  const prompt = buildScriptGenerationPrompt(input);
  
  const result = await models.thinking.generateContent({
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    generationConfig: {
      maxOutputTokens: 4000,
      temperature: 0.8, // Slightly higher for creative output
    },
  });
  
  return result.response.text();
}

// ===========================================
// STEP 3: Banger Check
// ===========================================
export async function runBangerCheck(input: BangerCheckInput) {
  const prompt = buildBangerCheckPrompt(input);
  
  const result = await models.thinking.generateContent({
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    generationConfig: {
      maxOutputTokens: 4000,
      temperature: 0.3, // Lower for more consistent scoring
    },
  });
  
  const text = result.response.text();
  
  // Parse the response
  return parseBangerCheckResult(text);
}

function parseBangerCheckResult(text: string) {
  // Extract scores
  const scores = {
    hookStrength: parseInt(text.match(/Hook Strength:\s*(\d+)/i)?.[1] || '0'),
    painDesire: parseInt(text.match(/Pain\/Desire:\s*(\d+)/i)?.[1] || '0'),
    proofMechanism: parseInt(text.match(/Proof(?:\sMechanism)?:\s*(\d+)/i)?.[1] || '0'),
    structurePacing: parseInt(text.match(/Structure(?:\s&\sPacing)?:\s*(\d+)/i)?.[1] || '0'),
    ctaStrength: parseInt(text.match(/CTA(?:\sStrength)?:\s*(\d+)/i)?.[1] || '0'),
    productionViability: parseInt(text.match(/Production(?:\sViability)?:\s*(\d+)/i)?.[1] || '0'),
  };
  
  const totalScore = parseInt(text.match(/TOTAL(?:\sSCORE)?:\s*(\d+)/i)?.[1] || '0');
  
  // Determine verdict
  let verdict: 'banger' | 'pass' | 'conditional' | 'fail' = 'fail';
  if (text.includes('BANGER')) verdict = 'banger';
  else if (text.includes('✅ PASS')) verdict = 'pass';
  else if (text.includes('CONDITIONAL')) verdict = 'conditional';
  
  // Extract rewrite if present
  const rewriteMatch = text.match(/REWRITTEN SCRIPT:([\s\S]*?)(?=REWRITE CHANGES|$)/i);
  
  return {
    scores,
    totalScore,
    verdict,
    passed: verdict === 'banger' || verdict === 'pass',
    rewrite: rewriteMatch ? rewriteMatch[1].trim() : undefined,
    rawResponse: text,
  };
}

// ===========================================
// STEP 4: Production Specs
// ===========================================
export async function generateProductionSpecs(
  script: string,
  characterSpecs: any,
  productionId: string
) {
  const prompt = `
${PROMPTS.HYBRID_PRODUCTION}

---

## YOUR TASK

Generate all 6 production specification documents for the following script.

APPROVED SCRIPT:
${script}

CHARACTER SPECS:
${JSON.stringify(characterSpecs, null, 2)}

PRODUCTION_ID: ${productionId}

Output each specification as a separate JSON code block labeled with the document name.
`;

  const result = await models.thinking.generateContent({
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    generationConfig: {
      maxOutputTokens: 8000,
      temperature: 0.5,
    },
  });
  
  const text = result.response.text();
  
  // Parse all JSON blocks
  const specs: any = {};
  
  const specNames = [
    'NANO_BANANA_PROMPTS',
    'CLING_ANIMATION_SPECS', 
    'AURORA_LIPSYNC_SPECS',
    'ELEVEN_LABS_SCRIPT',
    'CAPCUT_RECIPE',
    'TOPAZ_SETTINGS'
  ];
  
  for (const name of specNames) {
    const regex = new RegExp(`${name}[\\s\\S]*?\`\`\`json\\n([\\s\\S]*?)\\n\`\`\``, 'i');
    const match = text.match(regex);
    if (match) {
      specs[name] = JSON.parse(match[1]);
    }
  }
  
  return specs;
}

// ===========================================
// FULL PIPELINE ORCHESTRATOR
// ===========================================
export async function runFullPipeline(
  brandId: string,
  angleDescription: string,
  options: {
    track: 'organic' | 'ads';
    lengthSeconds: number;
    platform: string;
    competitorSource?: string;
  }
) {
  // In a real app, fetch brand/ICP/archetype from database
  const brand = await fetchBrandFromDb(brandId);
  const icp = await fetchICPFromDb(brandId);
  const archetype = await fetchArchetypeFromDb(brandId);
  
  console.log('📝 Step 2: Generating script...');
  const script = await generateScript({
    brandContext: brand,
    icpContext: icp,
    archetypeContext: archetype,
    angleDescription,
    track: options.track,
    lengthSeconds: options.lengthSeconds,
    platform: options.platform,
    competitorSourceUrl: options.competitorSource,
  });
  
  console.log('🎯 Step 3: Running banger check...');
  const check = await runBangerCheck({
    script,
    icpContext: icp,
    adType: options.track,
    adLength: `${options.lengthSeconds}s`,
  });
  
  if (!check.passed) {
    if (check.rewrite) {
      console.log('⚠️ Script needs rewrite, using improved version...');
      // Recurse with rewrite (max 2 attempts)
      return {
        status: 'conditional',
        originalScript: script,
        rewrittenScript: check.rewrite,
        bangerCheck: check,
      };
    }
    return {
      status: 'failed',
      script,
      bangerCheck: check,
    };
  }
  
  console.log('🎨 Step 4: Generating production specs...');
  const productionId = `prod_${Date.now()}`;
  const specs = await generateProductionSpecs(script, archetype, productionId);
  
  return {
    status: 'ready_for_production',
    script,
    bangerCheck: check,
    productionSpecs: specs,
    productionId,
  };
}

// Placeholder DB functions - replace with your Supabase queries
async function fetchBrandFromDb(brandId: string) {
  // return supabase.from('brands').select('*').eq('id', brandId).single();
  return { brandName: '', productDescription: '', keyDifferentiator: '' };
}

async function fetchICPFromDb(brandId: string) {
  // return supabase.from('brands').select('icp_*').eq('id', brandId).single();
  return { summary: '', painPoints: [], desires: [], languageToUse: [], languageToAvoid: [] };
}

async function fetchArchetypeFromDb(brandId: string) {
  // return supabase.from('brands').select('archetype_*').eq('id', brandId).single();
  return { name: '', age: '', aesthetic: '', energy: '', platformFit: '' };
}

export default {
  runBrandResearch,
  runCompetitorMonitor,
  generateScript,
  runBangerCheck,
  generateProductionSpecs,
  runFullPipeline,
  PROMPTS,
};
